export interface GenerationState {
  status: 'idle' | 'optimizing' | 'generating' | 'complete' | 'error';
  error?: string;
}

export interface ThumbnailData {
  prompt: string;
  imageUrl: string | null;
}

export enum AspectRatio {
  SQUARE = '1:1',
  LANDSCAPE = '16:9',
  PORTRAIT = '9:16',
  FOUR_THREE = '4:3',
}
