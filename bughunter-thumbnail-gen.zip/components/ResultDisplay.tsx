import React from 'react';
import { Download, RefreshCw, Image as ImageIcon, Terminal } from 'lucide-react';

interface ResultDisplayProps {
  imageUrl: string | null;
  prompt: string;
  status: 'idle' | 'optimizing' | 'generating' | 'complete' | 'error';
  error?: string;
}

export const ResultDisplay: React.FC<ResultDisplayProps> = ({ imageUrl, prompt, status, error }) => {
  
  const handleDownload = () => {
    if (!imageUrl) return;
    const link = document.createElement('a');
    link.href = imageUrl;
    link.download = 'bughunter-thumbnail.jpg';
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  if (status === 'error') {
    return (
      <div className="bg-red-900/20 border border-red-500/50 rounded-2xl p-8 text-center h-full flex flex-col items-center justify-center">
        <div className="bg-red-500/10 p-4 rounded-full mb-4">
          <Terminal className="w-8 h-8 text-red-500" />
        </div>
        <h3 className="text-xl font-bold text-red-400 mb-2">Generation Failed</h3>
        <p className="text-red-200 max-w-md">{error || "An unexpected error occurred."}</p>
      </div>
    );
  }

  if (status === 'idle') {
    return (
      <div className="bg-cyber-800/50 border-2 border-dashed border-cyber-700 rounded-2xl p-8 h-full flex flex-col items-center justify-center text-slate-500 min-h-[400px]">
        <ImageIcon className="w-16 h-16 mb-4 opacity-50" />
        <p className="text-lg font-medium">Ready to Generate</p>
        <p className="text-sm">Enter topic details to start the engine</p>
      </div>
    );
  }

  return (
    <div className="space-y-6 h-full flex flex-col">
      <div className="bg-cyber-800 rounded-2xl border border-cyber-700 overflow-hidden shadow-2xl relative group flex-grow flex flex-col">
        <div className="relative aspect-video bg-black w-full flex items-center justify-center overflow-hidden">
          {imageUrl ? (
            <>
               <img 
                src={imageUrl} 
                alt="Generated Thumbnail" 
                className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-105"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-black/60 via-transparent to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300 flex items-end justify-end p-6">
                <button 
                  onClick={handleDownload}
                  className="bg-white text-black px-6 py-3 rounded-full font-bold flex items-center gap-2 hover:bg-slate-200 transition-colors"
                >
                  <Download className="w-5 h-5" />
                  Download
                </button>
              </div>
            </>
          ) : (
            <div className="flex flex-col items-center gap-4 p-8 text-center max-w-lg">
              <div className="relative">
                <div className="absolute inset-0 bg-cyber-500 blur-xl opacity-20 animate-pulse"></div>
                <RefreshCw className={`w-12 h-12 text-cyber-400 ${status !== 'complete' ? 'animate-spin' : ''}`} />
              </div>
              <h3 className="text-xl font-bold text-white">
                {status === 'optimizing' ? 'Analyzing Vulnerability Data...' : 'Rendering 3D Assets...'}
              </h3>
              <p className="text-slate-400 text-sm font-mono">
                {status === 'optimizing' ? 'Gemini Flash is constructing the perfect prompt.' : 'Imagen 3 is generating high-fidelity graphics.'}
              </p>
            </div>
          )}
        </div>
      </div>

      {prompt && (
        <div className="bg-black/30 rounded-xl p-4 border border-cyber-700/50">
          <div className="flex items-center gap-2 mb-2 text-xs font-bold text-cyber-500 uppercase tracking-wider">
            <Terminal className="w-3 h-3" />
            Generated Prompt
          </div>
          <p className="text-sm text-slate-400 font-mono leading-relaxed break-words">
            {prompt}
          </p>
        </div>
      )}
    </div>
  );
};
