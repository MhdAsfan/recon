import React from 'react';
import { ShieldCheck, Zap } from 'lucide-react';

export const Header: React.FC = () => {
  return (
    <header className="border-b border-cyber-700 bg-cyber-900/50 backdrop-blur-md sticky top-0 z-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-16 flex items-center justify-between">
        <div className="flex items-center gap-3">
          <div className="bg-cyber-accent/10 p-2 rounded-lg">
            <ShieldCheck className="w-6 h-6 text-cyber-accent" />
          </div>
          <div>
            <h1 className="text-xl font-bold text-white tracking-tight">BugHunter <span className="text-cyber-accent">Gen</span></h1>
            <p className="text-xs text-slate-400">Thumbnail Authorization: <span className="text-cyber-accent font-mono">BYPASSED</span></p>
          </div>
        </div>
        <div className="flex items-center gap-2 text-sm text-slate-400 font-mono">
          <Zap className="w-4 h-4 text-yellow-400" />
          <span>Powered by Gemini 2.5 & Imagen 3</span>
        </div>
      </div>
    </header>
  );
};
