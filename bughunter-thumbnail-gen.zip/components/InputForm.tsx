import React, { useState } from 'react';
import { Sparkles, FileText, Lock } from 'lucide-react';

interface InputFormProps {
  defaultTopic: string;
  defaultContent: string;
  onGenerate: (topic: string, content: string) => void;
  isProcessing: boolean;
}

export const InputForm: React.FC<InputFormProps> = ({ defaultTopic, defaultContent, onGenerate, isProcessing }) => {
  const [topic, setTopic] = useState(defaultTopic);
  const [content, setContent] = useState(defaultContent);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!topic.trim()) return;
    onGenerate(topic, content);
  };

  return (
    <div className="bg-cyber-800 rounded-2xl border border-cyber-700 p-6 shadow-xl">
      <div className="flex items-center gap-2 mb-6">
        <FileText className="w-5 h-5 text-cyber-400" />
        <h2 className="text-lg font-semibold text-white">Content Details</h2>
      </div>

      <form onSubmit={handleSubmit} className="space-y-6">
        <div>
          <label htmlFor="topic" className="block text-sm font-medium text-slate-300 mb-2">
            Video Title / Topic
          </label>
          <div className="relative">
            <input
              id="topic"
              type="text"
              value={topic}
              onChange={(e) => setTopic(e.target.value)}
              className="w-full bg-cyber-900 border border-cyber-700 rounded-lg px-4 py-3 text-white placeholder-slate-600 focus:ring-2 focus:ring-cyber-500 focus:border-transparent outline-none transition-all font-mono text-sm"
              placeholder="e.g. How to Find Authorization Bypass Bugs"
            />
            <Lock className="absolute right-3 top-3.5 w-4 h-4 text-slate-600" />
          </div>
        </div>

        <div>
          <label htmlFor="content" className="block text-sm font-medium text-slate-300 mb-2">
            Article Snippet / Context
          </label>
          <textarea
            id="content"
            rows={6}
            value={content}
            onChange={(e) => setContent(e.target.value)}
            className="w-full bg-cyber-900 border border-cyber-700 rounded-lg px-4 py-3 text-slate-300 placeholder-slate-600 focus:ring-2 focus:ring-cyber-500 focus:border-transparent outline-none transition-all text-sm resize-none font-mono"
            placeholder="Paste the article intro here for better context..."
          />
        </div>

        <button
          type="submit"
          disabled={isProcessing || !topic}
          className={`w-full flex items-center justify-center gap-2 py-4 rounded-lg font-bold text-white transition-all transform active:scale-95 ${
            isProcessing || !topic
              ? 'bg-cyber-700 cursor-not-allowed opacity-50'
              : 'bg-gradient-to-r from-cyber-500 to-cyber-accent hover:from-cyber-400 hover:to-emerald-400 shadow-lg shadow-cyber-500/20'
          }`}
        >
          {isProcessing ? (
            <>
              <div className="animate-spin rounded-full h-5 w-5 border-b-2 border-white"></div>
              <span>Processing...</span>
            </>
          ) : (
            <>
              <Sparkles className="w-5 h-5" />
              <span>Generate Thumbnail</span>
            </>
          )}
        </button>
      </form>
    </div>
  );
};
