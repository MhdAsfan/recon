import React, { useState, useCallback } from 'react';
import { Header } from './components/Header';
import { InputForm } from './components/InputForm';
import { ResultDisplay } from './components/ResultDisplay';
import { optimizePromptForThumbnail, generateThumbnailImage } from './services/geminiService';
import { GenerationState } from './types';

// Default content from the user's prompt to demonstrate immediate value
const DEFAULT_TOPIC = "How to Find Authorization Bypass Bugs (Easy Guide)";
const DEFAULT_CONTENT = `What's an Authorization Bug? Imagine you have a bank account. The bank checks: "Are you logged in?" (Authentication) but forgets "Do you OWN this account?" (Authorization). Authorization bugs happen when the app forgets to check ownership. Example: Changing user_id in an API call allows you to edit someone else's profile.`;

const App: React.FC = () => {
  const [genState, setGenState] = useState<GenerationState>({ status: 'idle' });
  const [generatedPrompt, setGeneratedPrompt] = useState<string>('');
  const [imageUrl, setImageUrl] = useState<string | null>(null);

  const handleGenerate = useCallback(async (topic: string, content: string) => {
    setGenState({ status: 'optimizing' });
    setGeneratedPrompt('');
    setImageUrl(null);

    try {
      // Step 1: Optimize Prompt
      const optimizedPrompt = await optimizePromptForThumbnail(topic, content);
      setGeneratedPrompt(optimizedPrompt);
      
      setGenState({ status: 'generating' });

      // Step 2: Generate Image
      const url = await generateThumbnailImage(optimizedPrompt);
      setImageUrl(url);
      
      setGenState({ status: 'complete' });
    } catch (error: any) {
      setGenState({ 
        status: 'error', 
        error: error.message || "An unknown error occurred during generation." 
      });
    }
  }, []);

  return (
    <div className="min-h-screen flex flex-col bg-cyber-900 selection:bg-cyber-500/30 selection:text-cyber-100">
      <Header />
      
      <main className="flex-grow p-4 sm:p-6 lg:p-8">
        <div className="max-w-7xl mx-auto grid grid-cols-1 lg:grid-cols-12 gap-8 h-full">
          
          {/* Left Column: Input */}
          <div className="lg:col-span-4 xl:col-span-3 space-y-6">
            <div className="prose prose-invert prose-sm mb-6">
              <p className="text-slate-400">
                Create eye-catching thumbnails for your bug bounty write-ups. 
                Paste your article topic below, and our AI will visualize the vulnerability.
              </p>
            </div>
            <InputForm 
              defaultTopic={DEFAULT_TOPIC}
              defaultContent={DEFAULT_CONTENT}
              onGenerate={handleGenerate}
              isProcessing={genState.status === 'optimizing' || genState.status === 'generating'}
            />
          </div>

          {/* Right Column: Output */}
          <div className="lg:col-span-8 xl:col-span-9 min-h-[500px]">
            <ResultDisplay 
              imageUrl={imageUrl} 
              prompt={generatedPrompt}
              status={genState.status}
              error={genState.error}
            />
          </div>
          
        </div>
      </main>
    </div>
  );
};

export default App;
