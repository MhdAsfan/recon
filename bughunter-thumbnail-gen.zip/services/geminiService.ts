import { GoogleGenAI } from "@google/genai";

const getAiClient = () => {
  const apiKey = process.env.API_KEY;
  if (!apiKey) {
    throw new Error("API Key not found");
  }
  return new GoogleGenAI({ apiKey });
};

/**
 * Uses Gemini Flash to analyze the article text and create a highly detailed
 * image generation prompt suitable for a YouTube thumbnail.
 */
export const optimizePromptForThumbnail = async (articleTopic: string, articleContent: string): Promise<string> => {
  try {
    const ai = getAiClient();
    const model = "gemini-2.5-flash";
    
    const systemInstruction = `
      You are an expert AI Art Director and YouTube Strategist. 
      Your goal is to write a highly detailed text-to-image prompt for a generative AI model (like Imagen 3) based on a provided article topic.
      
      The output should be a single string describing a high-quality, click-worthy YouTube thumbnail.
      
      Guidelines for the prompt:
      1.  **Subject**: Clear focal point related to the topic (e.g., a hacker in a hoodie, a digital lock breaking, matrix code, glowing shields).
      2.  **Style**: "Cyberpunk", "Digital Art", "High Tech", "Cinematic Lighting", "Unreal Engine 5 Render".
      3.  **Composition**: Leave some negative space for text (though don't ask for text in the image itself). 
      4.  **Colors**: High contrast. Neon greens, deep blues, or warning reds.
      5.  **Vibe**: Professional, intriguing, slightly mysterious but educational.
      
      Do NOT include markdown formatting. Just the raw prompt text.
    `;

    const userPrompt = `
      Topic: ${articleTopic}
      Context/Excerpt: ${articleContent.substring(0, 1000)}...
      
      Create the perfect image generation prompt for this topic.
    `;

    const response = await ai.models.generateContent({
      model,
      config: { systemInstruction },
      contents: userPrompt,
    });

    return response.text || "A secure digital lock being bypassed, cyberpunk style, 8k resolution.";
  } catch (error) {
    console.error("Error optimizing prompt:", error);
    throw new Error("Failed to optimize prompt. Please check your API key.");
  }
};

/**
 * Generates the actual image using Imagen 3/4.
 */
export const generateThumbnailImage = async (prompt: string): Promise<string> => {
  try {
    const ai = getAiClient();
    // Using the high-quality generation model
    const model = "imagen-4.0-generate-001"; 

    const response = await ai.models.generateImages({
      model,
      prompt,
      config: {
        numberOfImages: 1,
        aspectRatio: '16:9', // Standard for YouTube thumbnails
        outputMimeType: 'image/jpeg',
      },
    });

    const base64Image = response.generatedImages?.[0]?.image?.imageBytes;
    
    if (!base64Image) {
      throw new Error("No image data returned from API");
    }

    return `data:image/jpeg;base64,${base64Image}`;
  } catch (error) {
    console.error("Error generating image:", error);
    throw new Error("Failed to generate image. Ensure your API key has access to Imagen.");
  }
};
